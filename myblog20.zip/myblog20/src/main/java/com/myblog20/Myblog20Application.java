package com.myblog20;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Myblog20Application {

	public static void main(String[] args) {
		SpringApplication.run(Myblog20Application.class, args);
	}

}
